import React, { Component } from "react";

class Employee extends Component {
  state = {};

  render() {
    return (
      <React.Fragment>
        <table>
          <tr>
            <b>Name</b>&emsp; &emsp; &emsp;<b>Job</b>
          </tr>
          <tr>Charlie&emsp; &emsp; &emsp;Janitor</tr>
          <tr>Mac&emsp; &emsp; &emsp;Bouncer</tr>
          <tr>Dee&emsp; &nbsp; &nbsp; Aspiring Actress</tr>
          <tr>Denis&emsp; &emsp; &emsp;Bartender</tr>
        </table>
      </React.Fragment>
    );
  }
}

export default Employee;
