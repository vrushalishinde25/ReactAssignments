import React from "react";
import "./styles.css";

import Employee from "./components/Employee";

export default function App() {
  return (
    <div className="App">
      <Employee />
    </div>
  );
}
