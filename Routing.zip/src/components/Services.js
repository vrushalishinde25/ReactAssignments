import React from 'react'  
class Services extends React.Component {  
  render() {  
    return <h1>To Services Page</h1>  
  }  
}  
export default Services 