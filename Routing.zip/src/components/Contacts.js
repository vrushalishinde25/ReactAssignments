import React from "react";
class Contacts extends React.Component {
  render() {
    return <h1>To Contact Page</h1>;
  }
}
export default Contacts;
