import React from 'react'  
class Projects extends React.Component {  
  render() {  
    return <h1>To Project Page</h1>  
  }  
}  
export default Projects 